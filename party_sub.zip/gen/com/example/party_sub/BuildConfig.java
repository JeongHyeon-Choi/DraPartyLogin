/** Automatically generated file. DO NOT MODIFY */
package com.example.party_sub;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}